#define SIZE 8
void Initialization(char grid[SIZE + 5][SIZE + 5], int *point, int* turn);