#include"Check_situations.h"
#define SIZE 8
void make_changes_of_new_move(char grid[SIZE + 5][SIZE + 5], int turn, int row, int column, int *point);
