#include"Check_situations.h"
#define SIZE 8
void get_input(char grid[SIZE + 5][SIZE + 5], int turn, int* row, int* column);