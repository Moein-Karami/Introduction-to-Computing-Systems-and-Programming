#define SIZE 8
void print_grid(char grid[SIZE + 5][SIZE + 5], int *point);
